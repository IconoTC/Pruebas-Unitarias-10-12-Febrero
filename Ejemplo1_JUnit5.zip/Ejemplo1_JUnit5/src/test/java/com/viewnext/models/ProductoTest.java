package com.viewnext.models;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.Properties;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnJre;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;

import com.viewnext.utils.PrecioNegativoException;

public class ProductoTest {
	
	Producto producto;
	
	@BeforeAll
	static void inicioClasePrueba() {
		// Iniciamos el log p.e. para almacenar el resultado de las pruebas
		System.out.println("Empezando a probar la clase ProductoTest");
	}
	
	@AfterAll
	static void finClasePrueba() {
		System.out.println("Hemos terminado de probar la clase ProductoTest");
	}
	
	@BeforeEach
	void inicioMetodoTest() {
		producto = new Producto(1, "Impresora", 129.95);
		System.out.println("Producto creado para realizar la prueba");
	}
	
	@AfterEach
	void finalMetodoTest() {
		System.out.println("Prueba terminada");
	}
	
	// Testear la descripcion del producto
	@Test
	@DisplayName("Probando la descripcion del producto")
	void testDescripcion() {
		String descripcionReal = producto.getDescripcion();
		String descripcionEsperada = "Impresora";
		Assertions.assertEquals(descripcionEsperada, descripcionReal);
	}
	
	// Testear el precio del producto
	@Test
	@DisplayName("Probando el precio del producto")
	void testPrecio() {
		//Producto producto = new Producto(1, "Impresora", 129.95);
		//Assertions.assertTrue(producto.getPrecio() > 0);
		Assertions.assertFalse(producto.getPrecio() <= 0);
	}
	
	// Testear la igualdad de productos
	@Test
	@Disabled
	void testIgualdadProductos() {
		//Producto producto = new Producto(1, "Impresora", 129.95);
		Producto producto2 = new Producto(1, "Impresora", 129.95);
		Assertions.assertEquals(producto, producto2);
		
	}
	
	// Testear el precio del producto con excepcion personalizada
	@Test
	void testPrecioNegativoException() {
		//Producto producto = new Producto(1, "Impresora", 129.95);
		Exception exception = Assertions.assertThrows(PrecioNegativoException.class, () -> {
			producto.setPrecio(-10);
		} );
		
		String msgReal = exception.getMessage();
		String msgEsperado = "El precio no puede ser negativo";
		assertEquals(msgEsperado, msgReal);
	}
	
	// Testear la relacion entre producto y proveedor
	@Test
	void testRelacionProductoProveedor() {
		//Producto producto = new Producto(1, "Impresora", 129.95);
		Producto producto2 = new Producto(2, "Scanner", 237.50);
		
		Proveedor proveedor = new Proveedor();
		proveedor.setNombre("HP");
		
		proveedor.addProducto(producto);
		proveedor.addProducto(producto2);
		
		// Si la primera Asercion falla pues no continua con el resto
		/*
		Assertions.assertNotNull(proveedor.getProductos());
		
		Assertions.assertEquals(2, proveedor.getProductos().size(), 
				"El proveedor debe tener 2 productos");
		
		// El proveedor HP tiene el producto Impresora
		Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
				.filter(prod -> prod.getDescripcion().equals("Impresora"))
				.findFirst()
				.get()
				.getDescripcion());
		*/
		
		// Forzar para que se evaluen todas las aserciones haya fallos en las primeras o no
		Assertions.assertAll(() -> Assertions.assertNotNull(proveedor.getProductos()), 
				() -> Assertions.assertEquals(3, proveedor.getProductos().size(), 
						"El proveedor debe tener 2 productos"), 
				() -> Assertions.assertEquals("Impresoraaaa", proveedor.getProductos().stream()
						.filter(prod -> prod.getDescripcion().equals("Impresora"))
						.findFirst()
						.get()
						.getDescripcion()));
		
	}
	
	@Test
	@EnabledOnOs(OS.WINDOWS)
	void testSOWindows() {
		System.out.println("Tu SO es Windows");
	}
	
	@Test
	@EnabledOnOs({OS.MAC, OS.LINUX})
	void testSOMacLinux() {
		System.out.println("Tu SO es MAC o Linux");
	}
	
	@Test
	@DisabledOnOs(OS.WINDOWS)
	void testNoSOWindows() {
		System.out.println("Deshabilitado si tu SO es Windows");
	}
	
	@Test
	@EnabledOnJre(JRE.JAVA_8)
	void testSoloJava8() {
		System.out.println("Probando test en Java 8");
	}
	
	@Test
	@DisabledOnJre(JRE.JAVA_21)
	void testSoloJava21() {
		System.out.println("Probando test en Java 21");
	}
	
	@Test
	void verSystemProperties() {
		Properties properties = System.getProperties();
		properties.forEach((k,v) -> System.out.println(k +": " + v));
	}
	
	//java.version: 1.8.0_111
	@Test
	@EnabledIfSystemProperty(named = "java.version", matches = "1.8.0_111")
	void testJavaVersion() {
		System.out.println("Tu version de java es 1.8.0_111");
	}
	
	// Tambien funciona con expresiones regulares
	@Test
	@EnabledIfSystemProperty(named = "java.version", matches = "1.8.*")
	void testJavaVersion2() {
		System.out.println("Tu version de java es 1.8.*");
	}

}
