package com.viewnext.models;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestReporter;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.condition.DisabledIfEnvironmentVariable;
import org.junit.jupiter.api.condition.DisabledOnJre;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.viewnext.utils.PrecioNegativoException;

public class ProductoTest {
	
	Producto producto;
	
	
	// Los metodos anotados como @BeforeAll y @AfterAll siempre han de ir en
	// la clase principal, nunca en clases anidadas.
	@BeforeAll
	static void inicioClasePrueba() {
		// Iniciamos el log p.e. para almacenar el resultado de las pruebas
		System.out.println("Empezando a probar la clase ProductoTest");	
	}
	
	@AfterAll
	static void finClasePrueba() {
		System.out.println("Hemos terminado de probar la clase ProductoTest");
	}
	
	@BeforeEach
	void inicioMetodoTest() {
		producto = new Producto(1, "Impresora", 129.95);
		System.out.println("Producto creado para realizar la prueba");
	}
	
	@AfterEach
	void finalMetodoTest() {
		System.out.println("Prueba terminada");
	}
	
	@Nested
	@DisplayName("Probando los testde la clase producto")
	class ProductoPruebas{
		
		// Testear la descripcion del producto
		@Tag("producto")
		@Test
		@DisplayName("Probando la descripcion del producto")
		void testDescripcion() {
			String descripcionReal = producto.getDescripcion();
			String descripcionEsperada = "Impresora";
			Assertions.assertEquals(descripcionEsperada, descripcionReal);
		}
		
		// Testear el precio del producto
		@Tag("producto")
		@Test
		@DisplayName("Probando el precio del producto")
		void testPrecio() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			//Assertions.assertTrue(producto.getPrecio() > 0);
			Assertions.assertFalse(producto.getPrecio() <= 0);
		}
		
		// Testear la igualdad de productos
		@Test
		@Disabled
		void testIgualdadProductos() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			Producto producto2 = new Producto(1, "Impresora", 129.95);
			Assertions.assertEquals(producto, producto2);
			
		}
		
		// Testear el precio del producto con excepcion personalizada
		@Test
		void testPrecioNegativoException() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			Exception exception = Assertions.assertThrows(PrecioNegativoException.class, () -> {
				producto.setPrecio(-10);
			} );
			
			String msgReal = exception.getMessage();
			String msgEsperado = "El precio no puede ser negativo";
			assertEquals(msgEsperado, msgReal);
		}
	}
	
	
	@Nested
	@DisplayName("Probando los test de la clase proveedor")
	class testProveedor{
		
		// Testear la relacion entre producto y proveedor
		@Tag("proveedor")
		@Tag("producto")
		@Test
		void testRelacionProductoProveedor() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			Producto producto2 = new Producto(2, "Scanner", 237.50);
			
			Proveedor proveedor = new Proveedor();
			proveedor.setNombre("HP");
			
			proveedor.addProducto(producto);
			proveedor.addProducto(producto2);
			
			// Si la primera Asercion falla pues no continua con el resto
			/*
			Assertions.assertNotNull(proveedor.getProductos());
			
			Assertions.assertEquals(2, proveedor.getProductos().size(), 
					"El proveedor debe tener 2 productos");
			
			// El proveedor HP tiene el producto Impresora
			Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
					.filter(prod -> prod.getDescripcion().equals("Impresora"))
					.findFirst()
					.get()
					.getDescripcion());
			*/
			
			// Forzar para que se evaluen todas las aserciones haya fallos en las primeras o no
			Assertions.assertAll(() -> Assertions.assertNotNull(proveedor.getProductos()), 
					() -> Assertions.assertEquals(3, proveedor.getProductos().size(), 
							"El proveedor debe tener 2 productos"), 
					() -> Assertions.assertEquals("Impresoraaaa", proveedor.getProductos().stream()
							.filter(prod -> prod.getDescripcion().equals("Impresora"))
							.findFirst()
							.get()
							.getDescripcion()));
			
		}
	}
	
	
	@Nested
	@DisplayName("Habilitar o deshabilitar segun SO, JRE")
	class SO_JRE{
		@Test
		@EnabledOnOs(OS.WINDOWS)
		void testSOWindows() {
			System.out.println("Tu SO es Windows");
		}
		
		@Test
		@EnabledOnOs({OS.MAC, OS.LINUX})
		void testSOMacLinux() {
			System.out.println("Tu SO es MAC o Linux");
		}
		
		@Test
		@DisabledOnOs(OS.WINDOWS)
		void testNoSOWindows() {
			System.out.println("Deshabilitado si tu SO es Windows");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_8)
		void testSoloJava8() {
			System.out.println("Probando test en Java 8");
		}
		
		@Test
		@DisabledOnJre(JRE.JAVA_21)
		void testSoloJava21() {
			System.out.println("Probando test en Java 21");
		}
	}
	
	@Nested
	@DisplayName("Pruebas de System Properties")
	class SystemProperties{
		@Test
		void verSystemProperties() {
			Properties properties = System.getProperties();
			properties.forEach((k,v) -> System.out.println(k +": " + v));
		}
		
		//java.version: 1.8.0_111
		@Test
		@EnabledIfSystemProperty(named = "java.version", matches = "1.8.0_111")
		void testJavaVersion() {
			System.out.println("Tu version de java es 1.8.0_111");
		}
		
		// Tambien funciona con expresiones regulares
		@Test
		@EnabledIfSystemProperty(named = "java.version", matches = "1.8.*")
		void testJavaVersion2() {
			System.out.println("Tu version de java es 1.8.*");
		}
		
		@Test
		@EnabledIfSystemProperty(named = "ENV", matches = "dev")
		void testEnv() {
			System.out.println("Estamos en modo desarrollo");
		}
	}
	
	@Nested
	@DisplayName("Variables de entorno")
	class VariablesEntorno{
		@Test
		void verVariablesEntorno() {
			Map<String, String> variables = System.getenv();
			variables.forEach((k,v) -> System.out.println(k +": " + v));
		}
		
		@Test
		@EnabledIfEnvironmentVariable(named = "COMMAND_MODE", matches = "unix2003")
		void testCommandMode() {
			System.out.println("COMMAND_MODE: unix2003 -------------------");
		}
		
		@Test
		@EnabledIfEnvironmentVariable(named = "ENVIRONMENT", matches = "dev")
		void testEnvironment() {
			System.out.println("dev -------------------");
		}
		
		@Test
		@DisabledIfEnvironmentVariable(named = "ENVIRONMENT", matches = "prod")
		void testEnvironment2() {
			System.out.println("prod -------------------");
		}
	}
	
	
	@Test
	@DisplayName("Probando el precio del producto con assumptions")
	void testPrecioAssumptions() {
		//Producto producto = new Producto(1, "Impresora", 129.95);
		//Assertions.assertTrue(producto.getPrecio() > 0);
		
		// Habilitar o deshabilitar un test o parte del test en funcion de una condicion
		// de forma programatica
		boolean esDev = "dev".equals(System.getProperty("ENV"));
		//Assumptions.assumeTrue(esDev);
		
		Assumptions.assumingThat(esDev, () -> {
			Assertions.assertFalse(producto.getPrecio() <= 0);
			Assertions.assertEquals(129.90, producto.getPrecio());
		});
				
	}
	
	//@RepeatedTest(3)
	@RepeatedTest(value = 3, name="Repeticion {currentRepetition} de {totalRepetition}")
	void testRepetido(RepetitionInfo infoRep) {
		System.out.println("Estamos en la repeticion numero: " + infoRep.getCurrentRepetition());
		double numero = Math.random();
		Assertions.assertNotNull(numero);
		Assertions.assertTrue(numero > 0);
	}
	
	
	// Test parametrizados: se trata de pasar varios datos como parametros y 
	// asi realizar la prueba con cada uno de ellos
	//@ParameterizedTest
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@ValueSource(doubles = {129.95, -30, 275, 0})
	@DisplayName("Probando el precio del producto")
	void testPrecio(double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
		//Assertions.assertFalse(producto.getPrecio() <= 0);
	}
	
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@CsvSource({"0,129.95", "1,-30", "2,275", "3,0"})
	@DisplayName("Probando el precio del producto")
	void testPrecioCsvSource(String idx, String precio) {
		System.out.println(idx + " -> " + precio);
		producto.setPrecio(Double.parseDouble(precio));
		Assertions.assertTrue(producto.getPrecio() > 0);
		//Assertions.assertFalse(producto.getPrecio() <= 0);
	}
	
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@CsvFileSource(resources = "/datos.csv")
	@DisplayName("Probando el precio del producto")
	void testPrecioCsvFileSource(String precio) {
		System.out.println("Precio: " + precio);
		producto.setPrecio(Double.parseDouble(precio));
		Assertions.assertTrue(producto.getPrecio() > 0);
		//Assertions.assertFalse(producto.getPrecio() <= 0);
	}

	
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@MethodSource("queryPrecios")
	@DisplayName("Probando el precio del producto")
	void testPrecioMethodSource(Double precio) {
		System.out.println("Precio: " + precio);
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
		//Assertions.assertFalse(producto.getPrecio() <= 0);
	}
	
	static List<Double> queryPrecios(){
		// Simulamos que lanzamos una query a la BBDD para traer la lista de precios
		return Arrays.asList(129.95, -30.0, 275.0, 0.0);
	}
	
	@ParameterizedTest
	@CsvFileSource(resources = "/productos.csv")
	void testRelacionProductoProveedor(int id, String descripcion, double precio) {
		
		Proveedor proveedor = new Proveedor();
		proveedor.setNombre("HP");
		
		Producto producto = new Producto(id, descripcion, precio);
		proveedor.addProducto(producto);
		
		proveedor.getProductos().forEach(System.out::println);
		
		Assertions.assertEquals(1, proveedor.getProductos().size(), 
				"El proveedor debe tener 1 productos");
	}
	
	// Testear la descripcion del producto
	@Tag("producto")
	@Test
	@DisplayName("Probando la descripcion del producto")
	void testDescripcion2(TestInfo info, TestReporter reporter) {
		
		System.out.println(info.getDisplayName() + " ********");
		System.out.println(info.getTestMethod() + " ********");
		System.out.println(info.getTags() + " ********");
		
		
		
		String descripcionReal = producto.getDescripcion();
		String descripcionEsperada = "Impresora";
		Assertions.assertEquals(descripcionEsperada, descripcionReal);
	}
	
	
	// Queremos es que la prueba de fallo cuando alcance el timeout
	// Util para poder medir tiempos de espera excesivos.
	@Test
	@Timeout(value = 1000, unit = TimeUnit.MILLISECONDS)
	void testTimeout() throws InterruptedException {
		// Forzamos al hilo para que espere 2 segundos
		Thread.sleep(2000);
	}
	
	// Hay otra forma de hacer los mismo
	@Test
	void testTimeout2() throws InterruptedException {
		// Forzamos al hilo para que espere 2 segundos
		Assertions.assertTimeout(Duration.ofSeconds(1), () -> {
			Thread.sleep(500);
		});		
	}
	
}













