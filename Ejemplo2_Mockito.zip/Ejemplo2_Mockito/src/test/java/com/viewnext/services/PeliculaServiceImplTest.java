package com.viewnext.services;

import org.mockito.Mockito;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.viewnext.models.Pelicula;
import com.viewnext.repositories.ActorRepository;
import com.viewnext.repositories.PeliculaRepository;

public class PeliculaServiceImplTest {
	
	PeliculaRepository repository;
	ActorRepository actorRepository;
	PeliculaService service;

	@BeforeEach
	void inicioPrueba() {
		// Creo un mock (objeto ficticio del repository)
		// No se puede crear un mock de cualquier metodo, solo publicos o default,
		// nunca de un método privado o estatico y tampoco final
		repository = Mockito.mock(PeliculaRepository.class);
		actorRepository = Mockito.mock(ActorRepository.class);
		service = new PeliculaServiceImpl(repository, actorRepository);
	}

	@Test
	void testFindPeliculaByNombre() {
		// Creamos los datos
		List<Pelicula> datos = Arrays.asList(new Pelicula(1L, "El 47"), 
				new Pelicula(2L, "La Infiltrada"),
				new Pelicula(3L, "La habitacion de al lado"));

		// Cargar los datos al llamar al findAll()
		Mockito.when(repository.findAll()).thenReturn(datos);
		Pelicula pelicula = service.findPeliculaByNombre("El 47");

		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
	}

}
