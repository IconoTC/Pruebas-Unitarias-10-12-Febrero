package com.viewnext.repositories;

import java.util.List;

public interface ActorRepository {
	
	List<String> findActoresByPeliculaId(Long id);

}
