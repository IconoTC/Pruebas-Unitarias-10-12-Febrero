package com.viewnext.repositories;

import java.util.List;

import com.viewnext.models.Pelicula;

public interface PeliculaRepository {
	
	List<Pelicula> findAll();

}
